<?php

/* Admin/Page/Blocks/pageContentRelationsSelect.html.twig */
class __TwigTemplate_811351c72a288fd08e9a64294756fbd4a5939c36780bfc6a7df2c9d5f6df1f97 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/Page/Blocks/pageContentRelationsSelect.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Admin/Page/Blocks/pageContentRelationsSelect.html.twig"));

        // line 1
        if (((isset($context["position"]) || array_key_exists("position", $context)) && (isset($context["location"]) || array_key_exists("location", $context)))) {
            // line 2
            echo "    <div class=\"form-group\">
        <label for=\"cat\">";
            // line 3
            echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 3, $this->source); })()), "html", null, true);
            echo "</label>
        <select id=\"cat\" name=\"location[";
            // line 4
            echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 4, $this->source); })()), "html", null, true);
            echo "][";
            echo twig_escape_filter($this->env, (isset($context["position"]) || array_key_exists("position", $context) ? $context["position"] : (function () { throw new Twig_Error_Runtime('Variable "position" does not exist.', 4, $this->source); })()), "html", null, true);
            echo "]\" class=\"form-control\">
            ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["categoryList"]) || array_key_exists("categoryList", $context) ? $context["categoryList"] : (function () { throw new Twig_Error_Runtime('Variable "categoryList" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 6
                echo "                <optgroup label=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["category"], "name", []), "html", null, true);
                echo "\">
                    ";
                // line 7
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["category"], "pageContents", []));
                foreach ($context['_seq'] as $context["_key"] => $context["pageContentOption"]) {
                    // line 8
                    echo "                        <option value=\"";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pageContentOption"], "id", []), "html", null, true);
                    echo "\"
                                ";
                    // line 9
                    if ( !twig_test_empty((isset($context["pageContent"]) || array_key_exists("pageContent", $context) ? $context["pageContent"] : (function () { throw new Twig_Error_Runtime('Variable "pageContent" does not exist.', 9, $this->source); })()))) {
                        // line 10
                        echo "                                    ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["pageContent"]) || array_key_exists("pageContent", $context) ? $context["pageContent"] : (function () { throw new Twig_Error_Runtime('Variable "pageContent" does not exist.', 10, $this->source); })()), "pageContentRelations", []));
                        foreach ($context['_seq'] as $context["_key"] => $context["relation"]) {
                            // line 11
                            echo "                                        ";
                            if ((twig_get_attribute($this->env, $this->source, $context["relation"], "location", []) == (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 11, $this->source); })()))) {
                                // line 12
                                echo "                                            ";
                                if ((twig_get_attribute($this->env, $this->source, $context["relation"], "position", []) == (isset($context["position"]) || array_key_exists("position", $context) ? $context["position"] : (function () { throw new Twig_Error_Runtime('Variable "position" does not exist.', 12, $this->source); })()))) {
                                    // line 13
                                    echo "                                                ";
                                    if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["relation"], "pageContentLinked", []), "id", []) == twig_get_attribute($this->env, $this->source, $context["pageContentOption"], "id", []))) {
                                        // line 14
                                        echo "                                                    selected
                                                ";
                                    }
                                    // line 16
                                    echo "                                            ";
                                }
                                // line 17
                                echo "                                        ";
                            }
                            // line 18
                            echo "                                    ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['relation'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 19
                        echo "                                ";
                    }
                    // line 20
                    echo "                            >
                            ";
                    // line 21
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pageContentOption"], "title", []), "html", null, true);
                    echo "
                        </option>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pageContentOption'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 24
                echo "                </optgroup>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "        </select>
    </div>
";
        }
        // line 29
        echo "

";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Admin/Page/Blocks/pageContentRelationsSelect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 29,  116 => 26,  109 => 24,  100 => 21,  97 => 20,  94 => 19,  88 => 18,  85 => 17,  82 => 16,  78 => 14,  75 => 13,  72 => 12,  69 => 11,  64 => 10,  62 => 9,  57 => 8,  53 => 7,  48 => 6,  44 => 5,  38 => 4,  34 => 3,  31 => 2,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if position is defined and location is defined %}
    <div class=\"form-group\">
        <label for=\"cat\">{{ location }}</label>
        <select id=\"cat\" name=\"location[{{ location }}][{{ position }}]\" class=\"form-control\">
            {% for category in categoryList %}
                <optgroup label=\"{{ category.name }}\">
                    {% for pageContentOption in category.pageContents %}
                        <option value=\"{{ pageContentOption.id }}\"
                                {% if pageContent is not empty %}
                                    {% for relation in pageContent.pageContentRelations %}
                                        {% if relation.location == location %}
                                            {% if relation.position == position %}
                                                {% if relation.pageContentLinked.id == pageContentOption.id %}
                                                    selected
                                                {% endif %}
                                            {% endif %}
                                        {% endif %}
                                    {% endfor %}
                                {% endif %}
                            >
                            {{ pageContentOption.title }}
                        </option>
                    {% endfor %}
                </optgroup>
            {% endfor %}
        </select>
    </div>
{% endif %}


", "Admin/Page/Blocks/pageContentRelationsSelect.html.twig", "/home/deb116267/domains/aazaa.org/templates/Admin/Page/Blocks/pageContentRelationsSelect.html.twig");
    }
}
