<?php

/* Base/navbar.html.twig */
class __TwigTemplate_6bbc2096b5808a6c85a6af4ea150abf992243ced30775ac92e0be2d41dfaa488 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Base/navbar.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Base/navbar.html.twig"));

        // line 1
        echo "<div itemscope itemtype=\"http://schema.org/Organization\">
    <meta itemprop=\"name\" content=\"Aazaa.org\">
    <div itemprop=\"aggregateRating\" itemscope itemtype=\"http://schema.org/AggregateRating\">
        <meta itemprop=\"bestRating\" content=\"10\">
        <meta itemprop=\"ratingCount\" content=\"20\">
        <meta itemprop=\"ratingValue\" content=\"9\">
    </div>
</div>
";
        // line 9
        if (((isset($context["menuItems"]) || array_key_exists("menuItems", $context)) &&  !twig_test_empty((isset($context["menuItems"]) || array_key_exists("menuItems", $context) ? $context["menuItems"] : (function () { throw new Twig_Error_Runtime('Variable "menuItems" does not exist.', 9, $this->source); })())))) {
            // line 10
            echo "    <div class=\"container-fluid navbar-main navbar-inner-container\">
        <div class=\"container navbar-inner-container\">
            <div class=\"row menu-main-buttons\">
                ";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["menuItems"]) || array_key_exists("menuItems", $context) ? $context["menuItems"] : (function () { throw new Twig_Error_Runtime('Variable "menuItems" does not exist.', 13, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["menuItem"]) {
                // line 14
                echo "                    ";
                if ((((twig_get_attribute($this->env, $this->source, $context["menuItem"], "viewPosition", []) == "Boven") && twig_get_attribute($this->env, $this->source, $context["menuItem"], "pageContent", [])) && twig_get_attribute($this->env, $this->source, $context["menuItem"], "image", []))) {
                    // line 15
                    echo "                        <div class=\"col-md-3 col-sm-6 col-xs-12\">
                            <a href=\"";
                    // line 16
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("page_loader", ["slug" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["menuItem"], "pageContent", []), "path", [])]), "html", null, true);
                    echo "\">
                                <img src=\"";
                    // line 17
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["menuItem"], "image", []), "html", null, true);
                    echo "\" class=\"img-responsive\">
                            </a>
                        </div>
                    ";
                }
                // line 21
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menuItem'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 22
            echo "            </div>
        </div>

        <div class=\"navbar-header\">
            <button id=\"toggleMenu\" type=\"button\" class=\"btn btn-aazaa navbar-mobile-menu collapsed\" data-toggle=\"collapse\" data-target=\"#Menu\" aria-expanded=\"false\" onclick=\"openMainMenu(this)\"></button>
        </div>

        <div class=\"container navbar-inner-container\">
            <div class=\"collapse navbar-collapse\" id=\"Menu\">
                <ul class=\"nav navbar-nav\">
                    <li class=\"";
            // line 32
            if (((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new Twig_Error_Runtime('Variable "route" does not exist.', 32, $this->source); })()) == (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 32, $this->source); })()), "request", []), "schemeAndHttpHost", []) . $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index")))) {
                echo "active";
            }
            echo " hidden-sm hidden-md hidden-lg\"><a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index");
            echo "\">Home</a></li>
                    ";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["menuItems"]) || array_key_exists("menuItems", $context) ? $context["menuItems"] : (function () { throw new Twig_Error_Runtime('Variable "menuItems" does not exist.', 33, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["menuItem"]) {
                // line 34
                echo "                        ";
                if (((twig_get_attribute($this->env, $this->source, $context["menuItem"], "viewPosition", []) == "Hoofdmenu") && twig_get_attribute($this->env, $this->source, $context["menuItem"], "pageContent", []))) {
                    // line 35
                    echo "                            <li class=\"";
                    if (((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new Twig_Error_Runtime('Variable "route" does not exist.', 35, $this->source); })()) == (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 35, $this->source); })()), "request", []), "schemeAndHttpHost", []) . $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("page_loader", ["slug" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["menuItem"], "pageContent", []), "path", [])])))) {
                        echo "active";
                    }
                    echo "\"><a href=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("page_loader", ["slug" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["menuItem"], "pageContent", []), "path", [])]), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["menuItem"], "name", []), "html", null, true);
                    echo "</a></li>
                        ";
                }
                // line 37
                echo "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menuItem'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "                    <li class=\"";
            if (((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new Twig_Error_Runtime('Variable "route" does not exist.', 38, $this->source); })()) == "account_index")) {
                echo "active";
            }
            echo " hidden-sm hidden-md hidden-lg\"><a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_index");
            echo "\">";
            if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 38, $this->source); })()), "user", [])) {
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 38, $this->source); })()), "user", []), "username", []), "html", null, true);
            } else {
                echo "Inloggen";
            }
            echo "</a></li>
                </ul>
            </div>
        </div>
    </div>
";
        }
        // line 44
        echo "
<div class=\"container-fluid navbar-sub\">
    <div class=\"container navbar-inner-container\">
        <div class=\"col-md-3 col-sm-3 hidden-xs text-center\">
            <a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index");
        echo "\" ><img class=\"img-responsive\" style=\"margin:auto; padding: 2px\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/home.png"), "html", null, true);
        echo "\" alt=\"Homepage\"></a>
        </div>
        <div class=\"no-padding col-md-6 col-sm-6 col-xs-12\">
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">

                <a target=\"_blank\" href=\"https://www.facebook.com/peter.aazaa\">
                    <img src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/facebook.png"), "html", null, true);
        echo "\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op Facebook\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a target=\"_blank\" href=\"https://www.instagram.com/aazaaacademy/\">
                    <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/instagram.png"), "html", null, true);
        echo "\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op Instagram\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a target=\"_blank\" href=\"https://www.pinterest.com/peteraazaa/\">
                    <img src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/pinterest.png"), "html", null, true);
        echo "\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op pinterest\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a href=\"mailto:info@aazaa.org\">
                    <img src=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/email.png"), "html", null, true);
        echo "\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Mail ons\">
                </a>
            </div>
        </div>
        <div class=\"col-md-3 col-sm-3 hidden-xs text-center\">
            <a href=\"";
        // line 74
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("account_index");
        echo "\" class=\"user\"><img class=\"img-responsive\" style=\"margin:auto; padding: 2px\"  src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/login.png"), "html", null, true);
        echo "\"></a>
        </div>
    </div>
</div>


";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Base/navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 74,  179 => 69,  171 => 64,  163 => 59,  155 => 54,  144 => 48,  138 => 44,  118 => 38,  112 => 37,  100 => 35,  97 => 34,  93 => 33,  85 => 32,  73 => 22,  67 => 21,  60 => 17,  56 => 16,  53 => 15,  50 => 14,  46 => 13,  41 => 10,  39 => 9,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div itemscope itemtype=\"http://schema.org/Organization\">
    <meta itemprop=\"name\" content=\"Aazaa.org\">
    <div itemprop=\"aggregateRating\" itemscope itemtype=\"http://schema.org/AggregateRating\">
        <meta itemprop=\"bestRating\" content=\"10\">
        <meta itemprop=\"ratingCount\" content=\"20\">
        <meta itemprop=\"ratingValue\" content=\"9\">
    </div>
</div>
{% if menuItems is defined and menuItems is not empty %}
    <div class=\"container-fluid navbar-main navbar-inner-container\">
        <div class=\"container navbar-inner-container\">
            <div class=\"row menu-main-buttons\">
                {% for menuItem in menuItems %}
                    {% if menuItem.viewPosition == 'Boven' and menuItem.pageContent and menuItem.image %}
                        <div class=\"col-md-3 col-sm-6 col-xs-12\">
                            <a href=\"{{ path('page_loader', {'slug': menuItem.pageContent.path }) }}\">
                                <img src=\"{{ menuItem.image }}\" class=\"img-responsive\">
                            </a>
                        </div>
                    {% endif %}
                {% endfor %}
            </div>
        </div>

        <div class=\"navbar-header\">
            <button id=\"toggleMenu\" type=\"button\" class=\"btn btn-aazaa navbar-mobile-menu collapsed\" data-toggle=\"collapse\" data-target=\"#Menu\" aria-expanded=\"false\" onclick=\"openMainMenu(this)\"></button>
        </div>

        <div class=\"container navbar-inner-container\">
            <div class=\"collapse navbar-collapse\" id=\"Menu\">
                <ul class=\"nav navbar-nav\">
                    <li class=\"{% if route == app.request.schemeAndHttpHost ~ path('index') %}active{% endif %} hidden-sm hidden-md hidden-lg\"><a href=\"{{ path('index') }}\">Home</a></li>
                    {% for menuItem in menuItems %}
                        {% if menuItem.viewPosition == 'Hoofdmenu' and menuItem.pageContent %}
                            <li class=\"{% if route == app.request.schemeAndHttpHost ~ path('page_loader', {'slug': menuItem.pageContent.path})  %}active{% endif %}\"><a href=\"{{ path('page_loader', {'slug': menuItem.pageContent.path}) }}\">{{ menuItem.name }}</a></li>
                        {% endif %}
                    {% endfor %}
                    <li class=\"{% if route == 'account_index' %}active{% endif %} hidden-sm hidden-md hidden-lg\"><a href=\"{{ path('account_index') }}\">{% if app.user %}{{ app.user.username }}{% else %}Inloggen{% endif %}</a></li>
                </ul>
            </div>
        </div>
    </div>
{% endif %}

<div class=\"container-fluid navbar-sub\">
    <div class=\"container navbar-inner-container\">
        <div class=\"col-md-3 col-sm-3 hidden-xs text-center\">
            <a href=\"{{ path('index') }}\" ><img class=\"img-responsive\" style=\"margin:auto; padding: 2px\" src=\"{{ asset('images/home.png') }}\" alt=\"Homepage\"></a>
        </div>
        <div class=\"no-padding col-md-6 col-sm-6 col-xs-12\">
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">

                <a target=\"_blank\" href=\"https://www.facebook.com/peter.aazaa\">
                    <img src=\"{{ asset('images/facebook.png') }}\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op Facebook\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a target=\"_blank\" href=\"https://www.instagram.com/aazaaacademy/\">
                    <img src=\"{{ asset('images/instagram.png') }}\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op Instagram\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a target=\"_blank\" href=\"https://www.pinterest.com/peteraazaa/\">
                    <img src=\"{{ asset('images/pinterest.png') }}\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Aazaa op pinterest\">
                </a>
            </div>
            <div class=\"col-xs-3 col-md-3 no-padding text-center\">
                <a href=\"mailto:info@aazaa.org\">
                    <img src=\"{{ asset('images/email.png') }}\" class=\"img-responsive\" style=\"width: 30px; margin-left: auto; margin-right: auto;display: block;\" alt=\"Mail ons\">
                </a>
            </div>
        </div>
        <div class=\"col-md-3 col-sm-3 hidden-xs text-center\">
            <a href=\"{{ path('account_index') }}\" class=\"user\"><img class=\"img-responsive\" style=\"margin:auto; padding: 2px\"  src=\"{{ asset('images/login.png') }}\"></a>
        </div>
    </div>
</div>


", "Base/navbar.html.twig", "/home/deb116267/domains/aazaa.org/templates/Base/navbar.html.twig");
    }
}
